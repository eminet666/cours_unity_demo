# cours_unity_demo

# fichiers zip
* etape1.zip : gameObject / Components / Assets / Material
* etape2.zip : contrôle d'un gameObject / vie et mort d'un gameObject