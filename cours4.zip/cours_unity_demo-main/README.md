# cours_unity_demo

# fichiers zip
* cours1.zip : gameObject / Components / Assets / Material
* cours2.zip : contrôle d'un gameObject / vie et mort d'un gameObject
* cours3.zip : scène Head / préfabs / lookAt / coroutine
* cours4.zip : amélioration chute / rotation tête / couronne